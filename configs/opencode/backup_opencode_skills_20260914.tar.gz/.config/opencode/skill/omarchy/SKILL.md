---
name: omarchy
description: >
  Operates and configures Omarchy, an Arch-based Linux distribution built
  around the Hyprland tiling window manager and the Quickshell desktop shell.
  Documents the pinned reference source: the omarchy command surface (binary
  router, update, theme, plugin, menu, toggle, capture, network, package,
  notification, and hibernation commands), theming with colors.toml and
  templates, shell.json and shell.toml layout, shell plugins and IPC, updates
  and channels, migrations, provisioning and file layout, notifications, and
  the full end-user manual including keybindings. Use when managing or
  scripting an Omarchy desktop, applying themes or installing shell plugins,
  running updates or migrations, configuring shell.json, troubleshooting
  Omarchy behavior, or answering operator and end-user questions about
  documented commands and settings. Runtime code in bin/, shell/, config/,
  and etc/ is excluded from the source scope; commands and paths must be
  verified against the cited documentation.
---

# Omarchy Skill

## Overview

Omarchy is an Arch-based Linux distribution using Hyprland (tiling WM) and the Quickshell desktop shell, with Neovim, Chromium, Obsidian, LibreOffice, Kdenlive, OBS Studio and Winamp-style player preinstalled. It is not macOS/Windows-like — terminal and config files are the center of the experience. `[SRC:manual/01-welcome-to-omarchy.md:L3-L9]`

- **Source:** `https://github.com/basecamp/omarchy` (local mirror `/home/bap/Github/omarchy`, branch `quattro`)
- **Version:** 4.0.3 (file-layout + settings packages `omarchy`/`omarchy-settings`; source `version` file reads `4.0.0.alpha`, target version 4.0.3 is authoritative)
- **Compiled:** Quick tier (source-reading, T1-low citations `[SRC:...]`; no AST)
- **Surface:** 68 documented files (docs/, manual/, agents/skills/, AGENTS.md); 25 documented commands in the provenance map; confidence T1-low
- **Scope note:** runtime code (`bin/`, `shell/`, `config/`, `etc/`, `themes/`, `default/`, `install/`, `migrations/`, `test/`) is excluded — commands appear only as documented behavior, never reverse-engineered.

## Quick Start

Core end-user flows, every one a documented `omarchy ...` command:

```bash
# Apply the theme for a user
omarchy theme list
omarchy theme set tokyo-night
```
`[SRC:docs/theming.md:L3-L29][SRC:manual/06-themes.md:L3]`

```bash
# Install and list shell plugins (URL → ~/.config/omarchy/plugins/<id>/)
omarchy plugin list [--json]
omarchy plugin add https://example.com/my-plugin --enable
```
`[SRC:docs/omarchy-shell.md:L50-L89][SRC:manual/32-shell-plugins.md:L12-L26]`

```bash
# Update the whole system (the ONLY blessed path; raw pacman -Syu is guarded)
omarchy update
```
`[SRC:docs/update-process.md:L22-L99][SRC:manual/30-updates.md:L3-L8]`

```bash
# Take a screenshot: drag freeform, click window/monitor, or fullscreen
omarchy capture screenshot region [copy|save]
omarchy screenshot          # interactive smart-region
```
`[SRC:manual/12-screenshots-recording.md:L16-L22][SRC:agents/skills/visual-verification.md:L12-L19]`

```bash
# Install / remove a package, including AUR
omarchy pkg add <package>
omarchy pkg drop <package>   # also removes config + deps
```
`[SRC:manual/29-other-packages.md:L5-L9]`

<!-- [MANUAL:additional-notes] -->
<!-- Add custom notes here. This section is preserved during skill updates. -->
<!-- [/MANUAL:additional-notes] -->

## Common Workflows

**Change theme + pick background:**
`omarchy theme set <name>` → `_Style > Background_` copies an image into `~/.config/omarchy/backgrounds/<theme>/` → cycle the background with the keybinding `Super+Ctrl+Space`.
`[SRC:manual/06-themes.md:L3-L9][SRC:manual/39-backgrounds.md:L3-L5]`

**Manage shell plugins end-to-end:**
`omarchy plugin list` → `omarchy plugin add <url> --enable` → `omarchy plugin validate ./my-plugin` → `omarchy plugin remove <id>` (clone built-ins with `omarchy plugin clone omarchy.clock`).
`[SRC:docs/omarchy-shell.md:L50-L89][SRC:manual/32-shell-plugins.md:L57-L104]`

**Update, switch channel, rollback:**
`omarchy update` (10 GiB free check, snapper snapshot, transcripts) → channel via `Update > Channel` / `omarchy channel set <stable|rc|edge|dev>` → roll back by choosing a Limine snapshot at boot; `omarchy reinstall` resets configs + downgrades packages.
`[SRC:docs/update-process.md:L109-L258][SRC:manual/30-updates.md:L13-L37]`

**Capture, transcode, share:**
`omarchy capture screenshot fullscreen save` → `omarchy transcode ~/Videos/demo.mov mp4 1080p` (or `omarchy transcode ascii`) → share over LAN with `Super+Ctrl+S` (LocalSend) or `omarchy share file <path>`.
`[SRC:manual/12-screenshots-recording.md:L20-L78][SRC:manual/22-guis.md:L43-L54]`

**Diagnose a broken update or subsystem:**
Reboot into a Limine snapshot, collect `omarchy-debug` logs for `#omarchy-help`, then `omarchy reinstall` as the reset; a dead Wi-Fi/Bluetooth/audio/trackpad is reloadable under `Update > Hardware`.
`[SRC:manual/45-troubleshooting.md:L5-L27][SRC:docs/update-process.md:L292-L317]`

**Set a reminder or dictation:**
`omarchy reminder 7 'Tea ready'` (or `Super+Ctrl+R`); voice dictation via Voxtype (`F9` push-to-talk, `Super+Ctrl+X` toggle, config `~/.config/voxtype/config.toml`).
`[SRC:manual/09-reminders.md:L3][SRC:manual/11-text-extraction-dictation.md:L13-L15]`

## Key Commands

| Command | Purpose | Key params |
|---|---|---|
| `omarchy` root | Grouped router; shows groups/commands, `--help` everywhere | `commands --all|--markdown\|--json\|--check` |
| `omarchy update` | Blessed full-system update (pacman/yay guarded) | — |
| `omarchy theme set/list` | Apply/list themes; stages to `next-theme` | `set <name>` |
| `omarchy plugin add/list/enable/disable/remove/clone/validate` | Shell plugin lifecycle | `add <url> --enable`, `list --json` |
| `omarchy menu toggle/summon/close/refresh/ping` | Drive the Omarchy menu | `summon style.theme` |
| `omarchy toggle <thing>` | Toggle features; `omarchy-toggle-enabled <name>` probe | `idle`, `screensaver`, `nightlight`, `bar`, `suspend`, `hybrid gpu` |
| `omarchy capture screenshot <mode> [copy\|save]` | Screenshots (PNG → `~/Pictures`) | `region\|windows\|fullscreen` |
| `omarchy screenshot` | Interactive smart-region flow | — |
| `omarchy transcode <file> <fmt> <size>` | JPEG/PNG/MP4/GIF transcode; `ascii` for ASCII-art | `mp4 1080p`, `ascii [--width 100]` |
| `omarchy reminder <min> <msg>` | Countdown reminder toast | `7 'Tea ready'` |
| `omarchy weather location [--set ...]` | Weather notice source | `--set Malibu [lat,lon]`, `--clear` |
| `omarchy network password/band/speedtest` | Wi-Fi password, band pin, speed test | `password <iface>`, `band 5`, `speedtest down|up` |
| `omarchy dns [provider]` | Overall DNS provider | `dns Cloudflare` |
| `omarchy tailscale send <machine> [file...]` | Taildrop files to a tailnet machine | — |
| `omarchy default browser/agent/editor <name>` | Set session defaults (auto-installs) | `agent <name>`, `browser firefox` |
| `omarchy bar position/transparent/move/set/defaults` | Top-bar placement & config | `position bottom`, `bar set omarchy.clock format "dddd h:mm AP"` |
| `omarchy pkg add/drop <pkg>` | Package install/removal (+config+deps on drop) | AUR via `Install > AUR` |
| `omarchy powerprofiles list|set` | AC/battery power profiles | `set battery power-saver` |
| `omarchy hibernation setup|remove` | Enable/disable hibernation (swap subvolume) | — |
| `omarchy agent crash <pid>` / `crash mute <prog> [off]` | Crash diagnosis + mute | — |
| `omarchy audio tuning on|off|status` | PipeWire speaker tuning | — |
| `omarchy reinstall configs` | Destructive resync of user defaults | — |

Provenance per row: `[SRC:docs/cli-router.md:L130]`, `[SRC:docs/update-process.md:L22-L99]`, `[SRC:docs/theming.md:L3-L29]`, `[SRC:docs/omarchy-shell.md:L50-L89]`, `[SRC:docs/menu.md:L134-L167]`, `[SRC:manual/13-toggles-idle-screensaver.md:L7-L34]`, `[SRC:manual/12-screenshots-recording.md:L16-L22]`, `[SRC:manual/09-reminders.md:L3]`, `[SRC:manual/10-notices.md:L17]`, `[SRC:manual/35-networking.md:L11-L27]`, `[SRC:manual/17-ai.md:L27-L47]`, `[SRC:manual/05-the-top-bar.md:L90-L95]`, `[SRC:manual/29-other-packages.md:L5-L9]`, `[SRC:manual/36-system-sleep.md:L9-L19]`, `[SRC:docs/audio-tuning.md:L36-L50]`, `[SRC:manual/30-updates.md:L33-L37]`.

<!-- [MANUAL:additional-notes] -->
<!-- Add custom notes here. This section is preserved during skill updates. -->
<!-- [/MANUAL:additional-notes] -->

## Key Types

Most important configuration surfaces (values inline):

- **colors.toml theme tokens**: `accent` (`#7aa2f7` default), `selection`, `muted`, `background`, `foreground`, `red…blue`, plus `dark_`/`lighter_`/`bright_` variants; legacy aliases `bg`/`fg` map to `background`/`foreground`. `[SRC:docs/theming.md:L68-L127]`
- **Template placeholders**: `{{ accent }}`, `{{ accent_strip }}` (no `#`), `{{ accent_rgb }}`, `{{ mix accent accent_strip 0.5 }}`, gradients via `hypr_gradient`/`shell_gradient`/`gradient_start`. `[SRC:docs/theming.md:L131-L176]`
- **shell.toml sections**: `[bar] [controls] [popups] [tooltip] [notifications] [launcher] [menu] [polkit] [lock] [image-picker] [spacing] [font]`, overridable per-section via `shell.<section>.toml`. `[SRC:docs/theming.md:L178-L317]`
- **shell.json (canonical, no deep-merge)**: `{ "version": 1, "idle": {"screensaver": 150, "lock": 300}, "bar": {"id","position","transparent","centerAnchor","layout":{"left/center/right"}}, "plugins": [...] }`. `[SRC:docs/omarchy-shell.md:L126-L164]`
- **Plugin manifest (schemaVersion 1)**: `schemaVersion`, `id`, `name`, `version`, `kinds`, `entryPoints`; `kinds` ∈ `bar-widget|bar|panel|overlay|menu|service`. `[SRC:docs/omarchy-shell.md:L14-L46][SRC:manual/32-shell-plugins.md:L77-L88]`
- **Toggle names**: `nightlight`, `notification silencing`, `idle` (stay awake), `crash-capture`, `screensaver`, `bar`, `touchpad`, `touchscreen`, `suspend`, `hybrid gpu` (presence in `~/.local/state/omarchy/toggles/` = feature disabled). `[SRC:manual/13-toggles-idle-screensaver.md:L11-L34]`
- **Update channels**: `stable` (default), `rc` (pre-release), `edge` (dev builds + latest Arch), `dev` (git checkout `~/omarchy` + edge). `[SRC:manual/30-updates.md:L13-L19]`
- **CLI metadata keys** (`bin/omarchy`, first 80 comment lines): `omarchy:group=`, `:name=` (empty = root of group), `:summary=`, `:args=`, `:examples=` (values separated ` | `), `:alias=`/`:aliases=`, `:hidden=true`, `:requires-sudo=true`. `[SRC:agents/skills/command-metadata.md:L5-L23][SRC:docs/cli-router.md:L3-L130]`
- **Power profiles**: `performance`/`balanced`/`power-saver`, remembered per AC/battery state. `[SRC:manual/36-system-sleep.md:L7-L9]`

## Architecture at a Glance

- **Shell (Quickshell):** one long-running process; plugins `shell/plugins/`, third-party `~/.config/omarchy/plugins/<id>/`; IPC targets per-plugin with no `bar` target. `[SRC:docs/omarchy-shell.md:L14-L122][SRC:agents/skills/shell-dev.md:L5-L39]`
- **Router/CLI:** `bin/omarchy` longest-prefix dispatch, two-pass; groups from `GROUP_DESCRIPTIONS`. `[SRC:docs/cli-router.md:L3-L130]`
- **Theming:** `themes/<name>/`, `colors.toml` + `{{ }}` templates, staged via `next-theme`. `[SRC:docs/theming.md:L3-L29]`
- **Updates + migrations:** `omarchy update` pipeline, channels, per-user migration runner. `[SRC:docs/update-process.md:L22-L317][SRC:agents/skills/migrations.md:L5-L32]`
- **Provisioning/layout:** Seed→Finalize→Resync `$HOME` layers; `/etc/skel` seeds user defaults. `[SRC:docs/file-layout.md:L33-L49]`
- **Notifications:** shell is the daemon; `omarchy-notification-send` sender contract. `[SRC:docs/notifications.md:L3-L146]`
- **Menu:** `default/omarchy/omarchy-menu.jsonc` + user overlay `~/.config/omarchy/extensions/omarchy-menu.jsonc`. `[SRC:docs/menu.md:L3-L61]`
- **Capture/media:** GPU screen-recorder, webcam overlay, transcode, LocalSend. `[SRC:manual/12-screenshots-recording.md:L39-L78]`
- **AI agents:** mise-managed stubs in `~/.local/bin/`; default agent wiring. `[SRC:manual/17-ai.md:L3-L33]`
- **Testing:** `./test/all`, `./test/cli`, `./test/shell`; acceptance suite in a VM. `[SRC:docs/testing.md:L9-L33][SRC:agents/skills/acceptance-tests.md:L6-L33]`

## CLI

- `omarchy` (no args) lists groups and commands; every group/command has `--help`. `[SRC:manual/14-omarchy-cli.md:L5-L58]`
- Group naming: commands are `omarchy-<group>-<name>`, routed as `omarchy <group> <name ...>`, prefixes `cmd- capture- pkg- hw- refresh- restart- launch- install- setup- toggle- theme- update-`. `[SRC:AGENTS.md:L36-L59]`
- Listing API: `omarchy commands --all | --markdown | --json | --check`. `[SRC:docs/cli-router.md:L130]`
- Nested tools follow helpers: `omarchy-cmd-{present,missing}`, `omarchy-pkg-{present,missing,add,drop}`, `omarchy-notification-send`, `omarchy-hw-asus-rog`. `[SRC:AGENTS.md:L79-L88]`

## Full API Reference

Deep per-command parameters, config formats, and lifecycle details live in `references/`:

- `references/cli-commands.md` — every documented command with params and effects
- `references/theming-config.md` — colors.toml tokens, placeholders, shell.toml, themed `.tpl` templates
- `references/shell-plugins-ipc.md` — manifest schema, IPC namespaces, third-party facades, bar layout, menu JSONC
- `references/update-migrations-packages.md` — update flow/state files, channels, migration authoring, package/file layout, provisioning
- `references/keybindings-reference.md` — the full hotkey table
- `references/end-user-manual.md` — manual topics: apps/services, hardware, capture/media, installs, troubleshooting, FAQ
- `references/testing-development.md` — test suites, acceptance VM, icon font, visual verification

## Full Type Definitions

- Theming: `references/theming-config.md` (colors.toml key list, placeholder grammar, shell.toml section keys, spacing/font tokens, controls states).
- Shell config: `references/shell-plugins-ipc.md` (shell.json schema, bar layout, plugin manifest).
- Command metadata grammar: `references/cli-commands.md` (metadata keys + route derivation from filename stem).
- Migration conventions: `references/update-migrations-packages.md` (file naming, marker paths, ordering).
