# Omarchy CLI Command Reference

> Compiled at Quick tier (T1-low). Every claim traced to the pinned source (branch `quattro`, commit `5b91db50`).

## Contents

- [Routing and metadata](#routing-and-metadata)
- [Command reference](#command-reference)
  - [Core system](#core-system)
  - [Theme and style](#theme-and-style)
  - [Plugins and shell](#plugins-and-shell)
  - [Menu](#menu)
  - [Toggles and power](#toggles-and-power)
  - [Capture and media](#capture-and-media)
  - [Network](#network)
  - [Notifications](#notifications)
  - [Packages and defaults](#packages-and-defaults)
  - [AI and diagnostics](#ai-and-diagnostics)

## Routing and metadata

- The binary router derives every command from a `bin/omarchy-<group>-<name>` stem: the first hyphen splits group/name, remaining hyphens become spaces (so `omarchy-theme-set` runs when the user types `omarchy theme set`). There is no registry; group bounds come from `GROUP_DESCRIPTIONS`. `[SRC:docs/cli-router.md:L3-L130]`
- Two routes per command (canonical + its filename); dispatch is longest-prefix over two passes (fast path: hyphen + executable probe, then the metadata table). `[SRC:docs/cli-router.md:L3-L130]`
- `--help`/`-h` is intercepted anywhere on the line; `--` ends the option scan; a bare `omarchy` invocation triggers a group-guard. `[SRC:docs/cli-router.md:L3-L130]`
- Metadata comes from the first 80 comment lines of the script, keys: `# omarchy:group=`, `:name=` (empty value = root of the group), `:summary=`, `:args=`, `:examples=` (values separated by ` | `), `:alias=`/`:aliases=`, `:hidden=true`, `:requires-sudo=true`. `[SRC:agents/skills/command-metadata.md:L9-L23]`
- List the whole surface: `omarchy commands --all | --markdown | --json | --check`. `[SRC:docs/cli-router.md:L130][SRC:manual/14-omarchy-cli.md:L15]`
- Helper commmands for skill contexts: `omarchy-cmd-present`, `omarchy-cmd-missing`, `omarchy-pkg-present`, `omarchy-pkg-missing`, `omarchy-pkg-add`, `omarchy-pkg-drop`, `omarchy-notification-send`, `omarchy-hw-asus-rog`. `[SRC:AGENTS.md:L79-L88]`

## Command reference

### Core system

`omarchy update` — the only blessed update path.
- Free-space check (10 GiB), snapper snapshot, stay-awake, transcripts in the log. `[SRC:docs/update-process.md:L22-L149]`
- Direct `pacman -Syu`/`yay -Syu` is blocked by `/usr/share/libalpm/hooks/00-omarchy-update-guard.hook`; deliberate bypass: `sudo env OMARCHY_ALLOW_DIRECT_PACMAN=1 pacman -Syu`. `[SRC:docs/update-process.md:L22-L99]`
- State files: `update.lock`, `/tmp/omarchy-update.log`, `current/`, `migrations/`, `reboot-required`, `restart-*-required`. `[SRC:docs/update-process.md:L22-L99]`

`omarchy channel set <stable|rc|edge|dev>` (a.k.a. `omarchy-channel-set`) — switch update channel. `[SRC:docs/update-process.md:L246-L258]`

`omarchy reinstall configs` — destructive resync of user defaults into the current `$HOME`. `[SRC:manual/30-updates.md:L33-L37][SRC:agents/skills/install-scripts.md:L10]`

### Theme and style

`omarchy theme list` / `omarchy theme set <name>` — list installed themes and apply one.
- Apply stages state under `~/.local/state/omarchy/current/next-theme`. `[SRC:docs/theming.md:L20-L29]`
- Only theme the listed apps unless OS-wide templates exist (see `references/theming-config.md`). `[SRC:docs/theming.md:L3-L176]`
- `omarchy transcode ascii` also doubles as the manual ASCII-art converter for branding files. `[SRC:manual/41-branding.md:L42-L45]`

### Plugins and shell

`omarchy plugin list [--json]` — list installed plugins; ids are namespaced `omarchy.*`. `[SRC:manual/32-shell-plugins.md:L12-L17][SRC:docs/omarchy-shell.md:L19-L46]`

`omarchy plugin add <url> --enable` — clone a git repo into `~/.config/omarchy/plugins/<id>/`; manifest must validate; no hook or sudo is ever run; updates are a fast-forward pull. `[SRC:docs/omarchy-shell.md:L50-L89]`

`omarchy plugin enable|disable <id>` — flip the plugin in the user `shell.json`. `[SRC:manual/32-shell-plugins.md:L22-L28]`

`omarchy plugin remove <id>` — symlinked plugin is unlinked; a bare-folder plugin is timestamped and backed up. `[SRC:manual/32-shell-plugins.md:L57-L59]`

`omarchy plugin clone <id>` — copy a built-in (e.g. `omarchy.clock`) into the user dir as `<user>.<id>`; hot-reloads on save. `[SRC:manual/32-shell-plugins.md:L63-L73]`

`omarchy plugin validate ./my-plugin` — check the manifest + structure locally. `[SRC:manual/32-shell-plugins.md:L92-L104]`

`omarchy-restart-shell` — restart the Quickshell process after QML changes (or after font-cache refreshes). `[SRC:agents/skills/shell-dev.md:L10]`

### Menu

`omarchy menu [toggle|summon|close|refresh|ping] [path]` — drive the Omarchy menu plugin from the CLI.
- `omarchy menu summon style.theme` jumps straight to a submenu; routes are case-insensitive and underscores map to dashes. `[SRC:docs/menu.md:L134-L167][SRC:manual/14-omarchy-cli.md:L62]`
- dmenu fallbacks: `omarchy-menu-select` / `omarchy-menu-input`. `[SRC:docs/menu.md:L134-L167]`

### Toggles and power

`omarchy toggle <name>` — flip toggles: `nightlight`, `idle` (stay awake), `screensaver`, `bar`, `touchpad`, `touchscreen`, `suspend`, `hybrid gpu`, `notification silencing`, `crash-capture`. Status is exit code of `omarchy-toggle-enabled <name>`; flag state lives in `~/.local/state/omarchy/toggles/` (file present = feature disabled). `[SRC:manual/13-toggles-idle-screensaver.md:L7-L34]`

`omarchy powerprofiles list|set <state> <profile>` — `state` ∈ `autodetect|battery|ac`, `profile` ∈ `performance|balanced|power-saver`; profiles remembered per power state. `[SRC:manual/36-system-sleep.md:L7-L9]`

`omarchy hibernation setup|remove` — create a `/swap` subvolume sized to RAM (limine required) and toggle the System menu hibernation entry. `[SRC:manual/36-system-sleep.md:L17-L19]`

### Capture and media

`omarchy capture screenshot region|windows|fullscreen [copy|save]` — PNG to `~/Pictures/screenshot-<timestamp>.png`, also on the clipboard + toast (override dirs via `OMARCHY_SCREENSHOT_DIR`, editor via `OMARCHY_SCREENSHOT_EDITOR`). `[SRC:manual/12-screenshots-recording.md:L18-L22]`

`omarchy screenshot` — interactive smart-region picker; drag freeform or click for window/monitor. `[SRC:manual/12-screenshots-recording.md:L16-L22]`

`omarchy transcode <file> <jpg|png|mp4|gif> <size>` — e.g. `omarchy transcode ~/Videos/demo.mov mp4 1080p`; `omarchy transcode ascii` for ASCII-art output. `[SRC:manual/12-screenshots-recording.md:L70-L74]`

`omarchy screenrecord --fullscreen` … `omarchy screenrecord --stop-recording` — MP4 via gpu-screen-recorder to `~/Videos/screenrecording-<timestamp>.mp4`. `[SRC:agents/skills/visual-verification.md:L24-L34][SRC:manual/12-screenshots-recording.md:L39-L47]`

### Network

`omarchy network password <interface>` — print the Wi-Fi password (QR under `_Setup > Network > QR Code`). `[SRC:manual/35-networking.md:L9-L11]`

`omarchy network band 2.4|5|6|auto` — pin the Wi-Fi band (per-band, still roams between APs). `[SRC:manual/35-networking.md:L21-L23]`

`omarchy network speedtest down|up` — network speed test (disk test beside it: `omarchy disk speedtest`). `[SRC:manual/35-networking.md:L27-L39]`

`omarchy dns [provider]` — view or set the machine-wide DNS provider (`Cloudflare`, `Google`, or custom). `[SRC:manual/35-networking.md:L15-L17]`

`omarchy tailscale send <machine> [file...]` — Taildrop files to a tailnet machine; received files land in `~/Downloads`. `[SRC:manual/05-the-top-bar.md:L67][SRC:manual/35-networking.md:L37-L41]`

### Notifications

`omarchy-notification-send` — the only sanctioned notification sender (never raw `notify-send`).
- Flags: `-g|--glyph`, `--exec` (consumes the rest of the line; click runs it detached via `Util.execArgv`, never interpolated), `--image`, `-i|--icon`, `--app-name`, `-u|--urgency`, `-t|--expire-time`; unknown flags are a hard error. `[SRC:docs/notifications.md:L63-L146]`
- Sibling helpers: `omarchy-notification-{wait,dismiss,time,battery,weather}`. `[SRC:docs/notifications.md:L148-L162]`

### Packages and defaults

`omarchy pkg add <package>` / `omarchy pkg drop <package>` — install or remove (drop also removes config + deps); AUR reachable via `_Install > AUR`. `[SRC:manual/29-other-packages.md:L5-L9]`

`omarchy default <browser|agent|editor> <name>` — set session defaults (auto-installs on demand). `[SRC:manual/23-browsers.md:L9-L17][SRC:manual/17-ai.md:L27-L33]`

`omarchy bar position <top|bottom>` / `transparent toggle` / `move` / `set <id> <option> <value>` / `defaults` — top-bar placement and widget config (e.g. `omarchy bar set omarchy.clock format "dddd h:mm AP"`). `[SRC:manual/05-the-top-bar.md:L90-L95]`

### AI and diagnostics

`omarchy agent crash <pid>` — diagnose a crashed process via systemd-coredump. `[SRC:manual/17-ai.md:L43]`

`omarchy crash mute <program> [off]` — mute crash notifications for an app (list with bare `omarchy crash mute`). `[SRC:manual/17-ai.md:L47]`

`omarchy audio tuning on|off|status` — PipeWire speaker-tuner control. `[SRC:docs/audio-tuning.md:L36-L50]`

`omarchy weather location [--set <name> [lat,lon]|--clear]` — weather-notice source for `omarchy-notification-weather`. `[SRC:manual/10-notices.md:L17]`