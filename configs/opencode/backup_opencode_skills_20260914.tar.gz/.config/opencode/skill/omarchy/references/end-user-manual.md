# End-User Manual Digest

> Quick tier (T1-low). Digest of the 51-file `manual/` chapter set for operator/end-user Q&A. Deep install guides: `references/update-migrations-packages.md`.

## Contents

- [Apps and services](#apps-and-services)
- [Capture, media, sharing](#capture-media-sharing)
- [Networking and firewall](#networking-and-firewall)
- [Input and displays](#input-and-displays)
- [Desktop appearance](#desktop-appearance)
- [Install/dev environments](#installdev-environments)
- [Gaming](#gaming)
- [Troubleshooting and FAQ](#troubleshooting-and-faq)
- [Security and snapshots](#security-and-snapshots)
- [Branding](#branding)

## Apps and services

- **Files (Nautilus):** `Super+Shift+F`, in cwd `Super+Shift+Alt+F`; USB/SD autotmounted; double-click defaults imv (images), mpv (video), Document Viewer (PDF), Neovim (text). `[SRC:manual/22-guis.md:L5-L9]`
- **1Password:** `Super+Shift+/` auto-installs first time, installs the Chromium extension too; authorization prompts need Hardware Acceleration enabled in its settings. `[SRC:manual/24-commercial-apps-services.md:L9][SRC:manual/45-troubleshooting.md:L45-L49]`
- **Bitwarden/Spotify/Dropbox/Tailscale/ONCE/NordVPN:** installed under `_Install > Service`. `[SRC:manual/24-commercial-apps-services.md:L13-L37]`
- **LocalSend:** `Super+Ctrl+S`; CLI `omarchy share clipboard|file <path>|folder <path>`; firewall opens 53317. `[SRC:manual/22-guis.md:L43-L54]`
- **Web apps:** `_Install > Web App` (name/URL/icon); browser login needed first; hotkey in `bindings.lua`. `[SRC:manual/25-web-apps.md:L3-L11]`
- **Obsidian:** `Super+Shift+O`; choose the `Omarchy` theme inside Obsidian. `[SRC:manual/22-guis.md:L19]`
- **AI agents:** mise-managed lazy stubs `claude`, `codex`, `opencode`, `agy`, `copilot`, `crush`, `grok`, `pi`, `omp`, `ori`, `hermes`, `muse`, `cursor-agent`; terminal aliases `a` (default), `c` (OpenCode), `cx` (Claude Code), `cy` (Codex). `[SRC:manual/17-ai.md:L3-L33]`
- **Terminal TUIs:** install your own via `_Install > TUI` (name/command/style/icon). `[SRC:manual/21-tuis.md:L51]`

## Capture, media, sharing

- Screenshot keys + `omarchy screenshot`/`omarchy capture screenshot region|windows|fullscreen [copy|save]`; outputs to `~/Pictures`, also clipboard + toast. `[SRC:manual/12-screenshots-recording.md:L7-L22]`
- Recording MP4 via gpu-screen-recorder (60fps), post-processing trims first frame, normalizes to −14 LUFS. `[SRC:manual/12-screenshots-recording.md:L39-L47]`
- Webcam overlay resizable (`Super+Alt+[` / `]`); QR decode marks output sensitive (excluded from clipboard history). `[SRC:manual/12-screenshots-recording.md:L53-L66]`
- Transcode: `super+Ctrl+.` picker, or `omarchy transcode <file> <fmt> <size>`. `[SRC:manual/12-screenshots-recording.md:L70-L74]`
- *.pdf forms: fill only if the PDF has a form (Document Viewer); for handwriting use Xournal++ → `File > Export as PDF`. `[SRC:manual/27-filling-out-pdfs.md:L3-L8]`

## Networking and firewall

- NetworkManager handles Wi-Fi; drive it via the bar icon / `Super+Ctrl+W`, or `nmtui` and `omarchy network`. `[SRC:manual/35-networking.md:L3-L5]`
- Share Wi-Fi via QR (`_Setup > Network > QR Code`); print the password with `omarchy network password <iface>`. `[SRC:manual/35-networking.md:L9-L11]`
- DNS: DHCP by default; override machine-wide at `_Setup > Network > DNS` or `omarchy dns <provider>`. `[SRC:manual/35-networking.md:L15-L17]`
- Band pinning: `omarchy network band <2.4|5|6|auto>`. `[SRC:manual/35-networking.md:L21-L23]`
- Firewall default: block all inbound except 53317 (LocalSend); SSH off unless `_Setup > Security > SSHD` (port 22, rate-limited, authorize key); Docker locked via ufw-docker. `[SRC:manual/35-networking.md:L31-L33]`
- Tailscale panel: connect/disconnect, account switch, exit nodes; `s` send file, `c/n/d` copy IP/name/DNS; `omarchy tailscale send <machine> [file...]`; inbound files → `~/Downloads`. `[SRC:manual/35-networking.md:L37-L41]`

## Input and displays

- Input config `~/.config/hypr/input.lua` (`_Setup > Input`): `kb_layout`, `kb_options` (e.g. `compose:caps,shift:both_capslock_cancel,grp:alts_toggle`), `repeat_rate/delay`, `sensitivity`, `touchpad.natural_scroll`, `clickfinger_behavior`. `[SRC:manual/34-keyboard-mouse-trackpad.md:L3-L32]`
- Compose/CapsLock doubles as the xcompose key; remap to Right Alt with `compose:ralt`. `[SRC:manual/34-keyboard-mouse-trackpad.md:L40-L48]`
- Trackpad gestures via `hl.gesture`; CJK input via fcitx5 (`omarchy pkg add fcitx5-mozc` / `fcitx5-chinese-addons`). `[SRC:manual/34-keyboard-mouse-trackpad.md:L52-L62]`
- Monitor scale: default 2x for retina (PPI ≥ 218); quick cycle `Super+/` / `Super+Alt+/`; text size `omarchy display text size <9-20>`. `[SRC:manual/33-monitors.md:L5-L31]`
- Apple displays: brightness via `asdcontrol`; phantom-screen fix `hl.monitor({ output = "DP-2", disabled = true })`. `[SRC:manual/33-monitors.md:L51-L53]`

## Desktop appearance

- Fonts: JetBrainsMono Nerd Font default; change at `_Style > Font` (applies across terminal/bar); extra Nerd Fonts under `_Install > Style > Font`. `[SRC:manual/38-fonts.md:L3-L9]`
- Backgrounds: per-theme folder `~/.config/omarchy/backgrounds/<theme>`; cycle with `Super+Ctrl+Space`; video wallpapers supported (first monitor only audio, decodes per monitor). `[SRC:manual/39-backgrounds.md:L3-L9]`
- Prompt: Starship, config `~/.config/starship.toml`. `[SRC:manual/40-prompt.md:L3-L7]`
- Tray icons: hidden behind the expander by default, pin via right-click manager. `[SRC:manual/42-common-tweaks.md:L9]`
- Rounded corners / gaps: uncomment `rounding = 8` / `gaps_in = 0` / `gaps_out = 0` / `border_size = 0` in `~/.config/hypr/looknfeel.lua`. `[SRC:manual/42-common-tweaks.md:L13-L36]`

## Install/dev environments

- Dev environments via `_Install > Development` (Ruby/Node/Bun/Deno/Go/Rust/Python/Java/Elixir/.NET/OCaml/Zig/Clojure/Scala) managed by Mise; `mise use -g ruby`. `[SRC:manual/18-development-tools.md:L15-L19]`
- Docker + compose present; user in `docker` group needs `sudo docker` (alias `d` needs the group) or `_Setup > Security > Sudoless Docker`. `[SRC:manual/18-development-tools.md:L23-L29]`
- GitHub CLI lazy-installs on first `gh`; `ghui` is a PR TUI stub. `[SRC:manual/18-development-tools.md:L33-L37]`
- Shell goodies: `ff` (fuzzy file), zoxide `cd`, `rg`, `eza` (`lt`/`lsa`/`lta`), `fd`, `bat`, `tldr`, `yt-dlp`, `try`. `[SRC:manual/19-shell-tools.md:L5-L59]`
- Shell functions: `compress`/`decompress`, `iso2sd`, `format-drive`, `ga`/`gd` worktrees, `rsw`/`lsw`/`dsw` rsync watchers, `fip`/`dip`/`lip` SSH port-forwarding. `[SRC:manual/20-shell-functions.md:L7-L49]`

## Gaming

- All game installs: `_Install > Gaming` (Steam, RetroArch, Xbox Cloud, GeForce Now, Minecraft, Battle.net, Lutris, Heroic), remove via `_Remove > Gaming`. `[SRC:manual/26-gaming.md:L7]`
- RetroArch: BIOS → `~/Games/bios`, ROMs → `~/Games/roms`. `[SRC:manual/26-gaming.md:L21-L31]`
- Moonlight preinstalled; host via `omarchy install service sunshine`. `[SRC:manual/26-gaming.md:L63-L67]`

## Troubleshooting and FAQ

- Broken update → snapshot rollback → `omarchy-debug` logs for `#omarchy-help` → `omarchy reinstall`. `[SRC:manual/45-troubleshooting.md:L5]`
- Dead subsystem (Wi-Fi/BT/audio/trackpad) → `_Update > Hardware` reload first. `[SRC:manual/45-troubleshooting.md:L27]`
- Blocked by password/faillock → `Ctrl+Alt+F2` TTY, login root, `faillock --reset --user <user>`. `[SRC:manual/45-troubleshooting.md:L39]`
- Apps too large → drop `omarchy_gdk_scale` 2→1 in `~/.config/hypr/monitors.lua`. `[SRC:manual/45-troubleshooting.md:L9]`
- 12-hour clock → right-click clock, or `omarchy bar set omarchy.clock format "dddd h:mm AP"`. `[SRC:manual/46-faq.md:L21-L27]`
- Google sign-in in Chromium → `_Install > Service > Chromium Account`, restart browser. `[SRC:manual/46-faq.md:L43]`
- Printers → Print Settings; driverless IPP Everywhere; auto-discovery intentionally off. `[SRC:manual/46-faq.md:L47-L53]`
- Move screenshot dir → `export OMARCHY_SCREENSHOT_DIR=...` in a file under `~/.config/uwsm/env.d/` (same for `OMARCHY_SCREENRECORD_DIR`). `[SRC:manual/46-faq.md:L57-L65]`

## Security and snapshots

- Full-disk LUKS encryption mandatory on installs; two passwords (drive + login) changed under `_Update > Password`. `[SRC:manual/48-security.md:L5-L13]`
- Reset machine: `_Setup > Reset Computer`, type `reset`; wipes users + `/home`, packages, identity — installer machines only. `[SRC:manual/48-security.md:L17-L19]`
- Passwordless sudo: `_Setup > Security > Passwordless Sudo` (15-min window, self-revokes; `omarchy-sudo-passwordless <min>`). `[SRC:manual/48-security.md:L23-L25]`
- Signing key `40DFB630FF42BCFFB047046CF0134EE680CAC571` (pkgs@omarchy.org) via `omarchy-keyring`; ISO signature appends `.sig` to the URL. `[SRC:manual/48-security.md:L29-L31]`
- Snapshots per update, restore from Limine before decryption prompt; direct-boot entry via `_Setup > Direct Boot`. `[SRC:manual/47-system-snapshots.md:L3-L25]`

## Branding

- Plymouth preview: `omarchy plymouth preview <bg> <fg> <logo.png> <out.png>`; apply `omarchy plymouth set …`, revert `omarchy plymouth reset` (also themes SDDM login). `[SRC:manual/41-branding.md:L10-L15]`
- Screensaver/about text: `~/.config/omarchy/branding/screensaver.txt` + `about.txt` via `_Style > Screensaver` / `_Style > About`. `[SRC:manual/41-branding.md:L19-L31]`
- Words-as-logo: `omarchy ascii "Back in five" > ~/.config/omarchy/branding/screensaver.txt` (FIGlet font, letters+spaces only). `[SRC:manual/41-branding.md:L49-L55]`
- Unlock image: `unlock.png` + `preview-unlock.png`; make it transparent, preview via `omarchy plymouth preview`. `[SRC:manual/43-making-your-own-theme.md:L29]`