# Keybindings Reference

> Quick tier (T1-low). Traced to `manual/04-navigation.md`, `manual/07-hotkeys.md`, `manual/13-*`, plus app chapters. Bindings config: `~/.config/hypr/bindings.lua`.

## Contents

- [Navigation and windows](#navigation-and-windows)
- [Workspaces and grouping](#workspaces-and-grouping)
- [System panels and actions](#system-panels-and-actions)
- [App launchers and web apps](#app-launchers-and-web-apps)
- [Clipboard, capture, dictation](#clipboard-capture-dictation)
- [Notifications, style, toggles](#notifications-style-toggles)
- [Tmux](#tmux)
- [Editors and terminal](#editors-and-terminal)
- [Reminders and notices](#reminders-and-notices)

## Navigation and windows

- `Super+Space` menu · `Super+Return` terminal · `Super+Shift+Return` browser · `Super+K` all main bindings. `[SRC:manual/04-navigation.md:L3-L5]`
- Focus: `Super+Arrows`; swap with `Super+Shift+Arrows`. `[SRC:manual/04-navigation.md:L13-L19]`
- `Super+W`/`Super+Q` close · `Ctrl+Alt+Delete` close all · `Super+F` fullscreen · `Super+Alt+F` full-width · `Super+Ctrl+F` fullscreen-in-window. `[SRC:manual/04-navigation.md:L25-L27][SRC:manual/07-hotkeys.md:L22]`
- `Super+T` float↔tile · `Super+J` position toggle · `Super+O` pop (sticky floating) · `Super+L` layout toggle · `Super+P` pseudo · resize `Super+Minus`/`Super+Equal` (Shift=smaller, Alt=bigger). `[SRC:manual/04-navigation.md:L15-L23][SRC:manual/07-hotkeys.md:L34-L39]`
- Mouse: `Super`+drag move, `Super`+right-drag resize, `Super+Scroll` workspace scroll. `[SRC:manual/07-hotkeys.md:L42-L44]`
- Zoom `Super+Ctrl+Z` / `Super+Ctrl+Alt+Z`; monitor scale `Super+/` and `Super+Alt+/`. `[SRC:manual/07-hotkeys.md:L52-L55]`
- `Alt+Tab` windows · `Ctrl+Alt+Tab` monitors. `[SRC:manual/07-hotkeys.md:L56-L59]`
- Scratchpad: `Super+Grave`/`Super+S` toggle; `Super+Shift+Grave`/`Super+Alt+S` send window to it. `[SRC:manual/04-navigation.md:L65]`

## Workspaces and grouping

- `Super+1/2/3/4` jump; `Super+Tab`/`Shift`/`Ctrl` next/prev/former; `Super+Shift+1/2/3/4` move window; `Super+Shift+Alt+n` move without following. `[SRC:manual/07-hotkeys.md:L23-L28]`
- Grouping: `Super+G` toggle · `Super+Alt+G` remove from group · `Super+Alt+Tab` cycle · `Super+Alt+1-9` jump · `Super+Ctrl+Arrows` navigate in-group. `[SRC:manual/04-navigation.md:L53-L59][SRC:manual/07-hotkeys.md:L45-L49]`

## System panels and actions

- `Super+Ctrl+A` audio · `+W` network · `+B` bluetooth · `+D` display · `+P` power · `Super+Ctrl+Alt+D` calendar. `[SRC:manual/05-the-top-bar.md:L42-L48]`
- `Super+Ctrl+S` LocalSend · `+T` btop · `+C` capture menu · `+O` toggle menu · `+H` hardware · `+Q` calculator · `+E` emoji · `+.` transcode. `[SRC:manual/07-hotkeys.md:L65-L80]`
- `Super+Escape` system menu · `Super+Ctrl+L` lock. `[SRC:manual/07-hotkeys.md:L9]`

## App launchers and web apps

- Terminal `Super+Return`; tmux `Super+Alt+Return`; Herdr `Super+Ctrl+Return`; browser `Super+Shift+Return`; incognito `Super+Shift+Alt+B`; file manager `Super+Shift+F` (in cwd: `+Alt+F`); Spotify `Super+Shift+M`; cliamp `Super+Shift+Alt+M`; 1Password `Super+Shift+/`; Neovim `Super+Shift+N`; HEY email `Super+Shift+E`; HEY calendar `Super+Shift+C`; ChatGPT `Super+Shift+A`; Grok `Super+Shift+Alt+A`; Signal `Super+Shift+G`; Photos `Super+Shift+P`; Maps `Super+Shift+S`; WhatsApp `Super+Shift+Alt+G`; Messages `Super+Shift+Ctrl+G`; LazyDocker `Super+Shift+D`; Obsidian `Super+Shift+O`; Omawrite `Super+Shift+W`; X `Super+Shift+X`; X Compose `Super+Shift+Alt+X`; YouTube `Super+Shift+Y`. `[SRC:manual/07-hotkeys.md:L97-L125]`

## Clipboard, capture, dictation

- `Super+C` copy · `Super+X` cut · `Super+V` paste (terminal included) · `Super+Ctrl+V` clipboard manager (text + images). `[SRC:manual/08-unified-clipboard-history.md:L7-L18]`
- `Print Screen` screenshot · `Alt+Print` screenrecord · `Super+Print` color picker · `Super+Ctrl+Print` OCR text extraction. `[SRC:manual/12-screenshots-recording.md:L7-L12]`
- Webcam overlay `Super+Alt+[` / `Super+Alt+]`; copy URL `Alt+Shift+L`; download video `Alt+Shift+D`; dictation `Super+Ctrl+X` toggle, `F9` push-to-talk. `[SRC:manual/07-hotkeys.md:L144-L154][SRC:manual/11-text-extraction-dictation.md:L15]`

## Notifications, style, toggles

- `Super+,` dismiss · `Super+Shift+,` all · `Super+Ctrl+,` silence (DND) · `Super+Alt+,` recent · `Super+Shift+Alt+,` history. `[SRC:manual/07-hotkeys.md:L163-L168]`
- Theme picker `Super+Ctrl+Shift+Space`; background `Super+Ctrl+Space`; transparency `Super+Backspace`; square aspect `Super+Ctrl+Backspace`; bar visibility `Super+Shift+Space`; gaps `Super+Shift+Backspace`; desktop fullscreen `Super+Ctrl+Alt+F`. `[SRC:manual/07-hotkeys.md:L174-L195]`
- Idle lock `Super+Ctrl+I`; nightlight `Super+Ctrl+N`; laptop display `Super+Ctrl+Delete`; mirror `Super+Ctrl+Alt+Delete`; next audio output `Shift+Mute`; next media source `Shift+Play`. `[SRC:manual/07-hotkeys.md:L187-L195]`

## Tmux

- Prefix: `Ctrl+Space` (also `Ctrl+B`); sessions persist/resume. `[SRC:manual/15-terminal.md:L13][SRC:manual/07-hotkeys.md:L215]`
- Panes: `Prefix+v` split beside, `Prefix+h` below, `Prefix+x` kill, `Prefix+z` zoom; no-prefix `Alt+Enter` below, `Alt+Shift+Enter` beside, `Alt+Escape` kill; `Ctrl+Alt+Arrows` move, `+Shift` resize. `[SRC:manual/07-hotkeys.md:L221-L229]`
- Windows: `Prefix+c/k/r`; `Alt+1-9` go; `Alt+Arrows`/`Alt+Shift+Arrows` move. `[SRC:manual/07-hotkeys.md:L235-L240]`
- Sessions: `Prefix+C/K/R/N/P`; `Prefix+s` list; `Prefix+d` detach. `[SRC:manual/07-hotkeys.md:L246-L253]`
- Copy mode: `Prefix+[`, `v` select, `y` copy. `[SRC:manual/07-hotkeys.md:L259-L261]`
- Layout helpers: `tdl <ai>` (IDE layout), `tds` (dev square), `tdlm <ai>` (per-dir), `tsl <count> <command>` (swarm); Herdr variants `hdl/hds/hdlm/hsl`. `[SRC:manual/15-terminal.md:L21-L37][SRC:manual/20-shell-functions.md:L19-L24]`

## Editors and terminal

- Ghostty: `Ctrl+Shift+E` split below · `Ctrl+Shift+O` beside · `Ctrl+Shift+T` tab · `Ctrl+Shift+Arrows` tabs · `Alt+N` tab · `Shift+PgUp/PgDn` scroll · `Ctrl+LMB` link. `[SRC:manual/07-hotkeys.md:L287-L296]`
- Default terminal Foot; switch at `_Setup > Defaults > Terminal`. `[SRC:manual/15-terminal.md:L3-L7]`
- File manager: `Ctrl+L` path · `Space` preview · `Backspace` back (`Super+Shift+F`). `[SRC:manual/07-hotkeys.md:L302-L304]`
- Neovim/LazyVim: `Space` options · `Space Space` fuzzy · `Space E` file tree · `Space G G` LazyGit · `Space S G` grep · `Ctrl+W W` sidebar ↔ editor · `Shift+H/L` tabs · `Space B D` close tab · `Space B O` close others · `Space U W` soft wrap; file tree `a/A/D/M/R`, `?` help. `[SRC:manual/16-neovim.md:L19-L34][SRC:manual/07-hotkeys.md:L312-L332]`

## Reminders and notices

- Reminders: `Super+Ctrl+R` set · `Super+Ctrl+Alt+R` view · `Super+Ctrl+Shift+R` clear all. `[SRC:manual/09-reminders.md:L3][SRC:manual/07-hotkeys.md:L201-L203]`
- Notices: `Super+Ctrl+Alt+T` time · `+B` battery · `+W` weather. `[SRC:manual/10-notices.md:L7-L21]`