# Shell Plugins & IPC Reference

> Quick tier (T1-low). Traced to `docs/omarchy-shell.md`, `agents/skills/shell-dev.md`, `docs/menu.md`, `manual/32-shell-plugins.md`.

## Contents

- [Process model](#process-model)
- [Plugin manifest](#plugin-manifest)
- [Plugin lifecycle](#plugin-lifecycle)
- [IPC namespaces](#ipc-namespaces)
- [Plugin authoring constraints](#plugin-authoring-constraints)
- [shell.json (canonical layout)](#shelljson-canonical-layout)
- [Bar layout and custom modules](#bar-layout-and-custom-modules)
- [Menu JSONC](#menu-jsonc)

## Process model

- One long-running Quickshell process is the whole shell; Hyprland autostart launches it with `quickshell -n -p`. Never start a second instance. `[SRC:agents/skills/shell-dev.md:L5-L9]`
- Restart it with `omarchy-restart-shell` (also needed after font-cache refreshes). `[SRC:agents/skills/shell-dev.md:L10][SRC:agents/skills/icon-font.md:L75]`
- The shell is the notification daemon (org.freedesktop.Notifications); there is no dunst/mako. `[SRC:docs/notifications.md:L3-L13]`

## Plugin manifest

- Every plugin has `manifest.json`. First-party live at `shell/plugins/` (one category deeper is fine; bar-only widgets may use an adjacent `*.manifest.json`); third-party at `~/.config/omarchy/plugins/<id>/manifest.json`. `[SRC:agents/skills/shell-dev.md:L13-L17]`
- Fields: `schemaVersion` (=1), `id`, `name`, `version`, `kinds`, `entryPoints` (activation optional). `[SRC:docs/omarchy-shell.md:L14-L46]`
- `kinds` enum: `bar-widget | bar | panel | overlay | menu | service`. `[SRC:docs/omarchy-shell.md:L14-L46][SRC:manual/32-shell-plugins.md:L77-L88]`
- Entry-point QML files are `Item`s (never `ShellRoot`); the shell injects props `omarchyPath`, `shell`, `manifest`, `pluginRegistry`/`barWidgetRegistry`. `[SRC:agents/skills/shell-dev.md:L23]`
- Third-party plugins receive capability-scoped façade objects, not the host shell tree. `[SRC:agents/skills/shell-dev.md:L23]`
- Panel/overlay/menu plugins expose `open(payloadJson)` and `close()` so the shell can summon/hide them. `[SRC:agents/skills/shell-dev.md:L24-L25]`

## Plugin lifecycle

- `omarchy plugin add <url> --enable`: clones the git repo into the user dir, validates the manifest, runs no hook and no sudo; updates are fast-forward pulls. `[SRC:docs/omarchy-shell.md:L50-L89]`
- Enabling state for third-party = id present in user `shell.json`; first-party are on unless named in `disabledPlugins[]`. `[SRC:manual/32-shell-plugins.md:L28]`
- `omarchy plugin remove <id>` unlinks symlinks and timestamp-backups bare folders. `[SRC:manual/32-shell-plugins.md:L57-L59]`
- Plugins are **unsandboxed** — treat URLs with care. `[SRC:docs/omarchy-shell.md:L50-L89]`

## IPC namespaces

- Canonical IPC entry point is `bin/omarchy-shell` (forwards to the running process; does not start one). `[SRC:agents/skills/shell-dev.md:L29-L31]`
- Shell target commands: `ping`, `summon`, `hide`, `toggle`, `call`, `rescanPlugins`, `reloadConfig`, `setPluginEnabled`, `listPlugins`. `[SRC:docs/omarchy-shell.md:L93-L122][SRC:agents/skills/shell-dev.md:L32-L35]`
- `shell.qml` also registers an image selector under `omarchy.image-picker`. `[SRC:agents/skills/shell-dev.md:L32-L35]`
- Plugin targets are named per plugin: `background`, `omarchy.indicators`, `omarchy.system-update`, `omarchy.clock`; **there is no `bar` target**. `[SRC:docs/omarchy-shell.md:L93-L122][SRC:agents/skills/shell-dev.md:L36-L39]`
- Notification DND IPC: `toggleDnd`, `setDnd`, `dndState`. `[SRC:docs/notifications.md:L41-L61]`

## Plugin authoring constraints

- Auth services must stay outside `ShellRoot._services` and outside the host QObject tree; do not expose auth through new third-party props. `[SRC:agents/skills/shell-dev.md:L23]`
- Custom bar widgets/modules are inline `{ "type": "command" | "qml", "exec", "interval", "tooltip", "onClick" }`. `[SRC:docs/omarchy-shell.md:L372-L395]`
- Widget files embed raw Nerd Font glyphs; never rewrite those files wholesale with editing tools — do targeted edits or `python3 -c 'print(chr(0x…))'`. `[SRC:agents/skills/shell-dev.md:L41-L47]`
- Visual changes are only done after reading `agents/skills/visual-verification.md` and verifying in the running UI. `[SRC:agents/skills/visual-verification.md:L3-L10]`

## shell.json (canonical layout)

- User file is `~/.config/omarchy/shell.json`; it is **canonical with no deep-merge** — once you customize it, new default widgets stop auto-appearing. `[SRC:docs/omarchy-shell.md:L126-L164]`
- Structure: `{ "version": 1, "idle": {"screensaver": <s>, "lock": <s>}, "bar": { "id", "position", "transparent", "centerAnchor", "layout": {"left"/"center"/"right"} }, "plugins": [...] }`. `[SRC:docs/omarchy-shell.md:L126-L164]`
- Idle defaults: screensaver 150s, lock 300s. `[SRC:manual/05-the-top-bar.md:L134]`

## Bar layout and custom modules

- Sections: left (logo, workspaces), center (status, clock, keyboard, weather, update badge), right (tray, agents, BT, network, audio, display, power). `[SRC:manual/05-the-top-bar.md:L9]`
- Widgets react to left/right/middle click and scroll; right/middle clicks hide secondary actions. `[SRC:manual/05-the-top-bar.md:L15]`
- Panel hotkeys: `Super+Ctrl+A` (audio), `+W` (network), `+B` (bluetooth), `+D` (display), `+P` (power), `Super+Ctrl+Alt+D` (calendar), `Super+Ctrl+1-9` (toggle nth panel). `[SRC:manual/05-the-top-bar.md:L42-L48]`

## Menu JSONC

- Data: source `default/omarchy/omarchy-menu.jsonc`; user overlay `~/.config/omarchy/extensions/omarchy-menu.jsonc`, watched live. `[SRC:docs/menu.md:L3-L13]`
- JSONC rules: whole-line `//` comments and trailing commas only. `[SRC:docs/menu.md:L15-L19]`
- Entry schema: dotted `id` (tree position), `kind` inferred (`action`/`target`/`submenu`), fields `icon`, `iconFont`, `label`, `title`, `action`, `target`, `provider`, `aliases`, `description`, `when`, `checked`, `disabled`; **no new aliases**. `[SRC:docs/menu.md:L22-L49]`
- Overlays merge per key; added menu entries must not collide. `[SRC:docs/menu.md:L52-L61]`
- Custom entries you add should live in the user overlay, not the source file. `[SRC:manual/31-dotfiles.md:L50-L55]`
- Providers: `apps` = the AppLibrary (never routable); `fonts`/`power-profiles` = bash one-liners. `[SRC:docs/menu.md:L101-L131]`
- Menu retention: adding aliases is forbidden by design; keep review in `MenuModel.js` changes Node-testable. `[SRC:docs/menu.md:L3-L13]`