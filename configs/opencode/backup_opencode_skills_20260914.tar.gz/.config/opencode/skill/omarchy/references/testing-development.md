# Testing & Development Workflows

> Quick tier (T1-low). Traced to `docs/testing.md`, `agents/skills/acceptance-tests.md`, `agents/skills/visual-verification.md`, `agents/skills/icon-font.md`, `agents/skills/command-metadata.md`.

## Contents

- [Unit suites](#unit-suites)
- [Acceptance suite (VM)](#acceptance-suite-vm)
- [Visual verification](#visual-verification)
- [Icon font workflow](#icon-font-workflow)
- [Command metadata hygiene](#command-metadata-hygiene)

## Unit suites

- Entrypoints: `./test/all`, `./test/cli` (router + metadata lint + theme pipeline), `./test/shell` (auto-discovers `test/shell.d/*-test.sh`; drop in a new `*-test.sh`). `[SRC:docs/testing.md:L9-L33]`
- Base contract (`base-test.sh`): `set -euo pipefail`, emit `ok -`/`not ok -` lines, `require_command` for deps. `[SRC:docs/testing.md:L35-L66]`
- `require_compositor` skips as pass when no compositor. `[SRC:docs/testing.md:L68-L90]`
- JS unit tests via `run_node_test` + guarded `module.exports`. `[SRC:docs/testing.md:L92-L118]`
- Conventions: stub the world, run real code; fake `$HOME`; run migrations twice to prove idempotence; drop one-shot migration tests once a release freezes. `[SRC:docs/testing.md:L120-L134]`

## Acceptance suite (VM)

- Graphical suite lives in `test/acceptance.d/*-test.sh` (helpers `test/acceptance.d/base-test.sh`); it runs only inside a disposable VM built from the `omarchy-iso` repo — never in the dev session. `[SRC:agents/skills/acceptance-tests.md:L6-L14]`
- Drive it from the ISO repo: `./bin/omarchy-iso-test release/<iso>.iso --reuse-base --sync-omarchy ../omarchy --no-preview`; add `--sync-all ../omarchy` to include `bin/`, `config/`, `shell/`. `[SRC:agents/skills/acceptance-tests.md:L18-L24]`
- Changing a package manifest/install/dependency requires a fresh ISO: `omarchy-iso-make --no-boot-offer --local-source`, then test it. `[SRC:agents/skills/acceptance-tests.md:L25-L33]`
- The runner keeps going past failed files, traps restore VM state, snapshots `success-<step>.png` / `failure-<step>.png`, and gathers logs + screenshots into a timestamped `test-runs/`. `[SRC:agents/skills/acceptance-tests.md:L35-L42]`
- Compositor-level shortcuts are proven with the QMP virtual keyboard only — `wtype` types into the focused control and cannot prove a global Hyprland binding. `[SRC:agents/skills/acceptance-tests.md:L44-L46]`

## Visual verification

- Read `agents/skills/visual-verification.md` before finishing ANY visual change (shell styling/layout, panels, menus, notifications, desktop appearance, animations, screenshots, recording). `[SRC:agents/skills/visual-verification.md:L3-L5]`
- Verify in the running UI next to automated tests; check clipping/overlap/spacing/stale state/focus/regression. `[SRC:agents/skills/visual-verification.md:L6-L10]`
- Fullscreen capture: `omarchy capture screenshot fullscreen save`; interactive: `omarchy screenshot`; compare reference vs candidate captures. `[SRC:agents/skills/visual-verification.md:L12-L21]`
- Video: `omarchy screenrecord --fullscreen` → exercise UI → `omarchy screenrecord --stop-recording`. `[SRC:agents/skills/visual-verification.md:L24-L34]`
- Simulate keyboard with `wtype` (e.g. `wtype -k Right -k Return`); track the UI process PID you launched and stop it after capturing; avoid broad kills unless `ps`-confirmed. `[SRC:agents/skills/visual-verification.md:L36-L44]`

## Icon font workflow

- Custom glyph font: `default/fonts/omarchy/omarchy.ttf`; private-use codepoints for the logo + brand agent/app marks; used from menus via the `"iconFont":"omarchy"` entry field. `[SRC:agents/skills/icon-font.md:L3-L11]`
- Only add a mark when a Nerd Font glyph genuinely misrepresents the brand (e.g. one generic robot for four AI apps — yes; folder/microphone — no). `[SRC:agents/skills/icon-font.md:L13-L16]`
- Add a glyph: `omarchy dev font list`; `omarchy dev font add <name> <svg-url>` — it scales into the 64..960 box, allocates the next free codepoint, appends a `default/fonts/omarchy/README.md` provenance line, prints codepoint + glyph. `[SRC:agents/skills/icon-font.md:L23-L33]`
- Sources MUST be monochrome SVGs with a single `<path>` (the menu recolors by theme fg/selection); prioritize simpleicons.org flat marks; two-tone artwork is a trap. `[SRC:agents/skills/icon-font.md:L35-L45]`
- After adding: point the menu entry at the new codepoint with `iconFont: omarchy`, extend the charset range asserted in `test/shell.d/menu-test.sh`, and give the README entry a proper display name with `--label`. `[SRC:agents/skills/icon-font.md:L49-L55]`
- The font ships in the `omarchy-settings` package to `/usr/share/fonts/omarchy/omarchy.ttf` — release it via a settings release, not `omarchy update`. `[SRC:agents/skills/icon-font.md:L57-L60]`
- Verify by rendering the whole font (decode codepoints with `python3 -c 'print(chr(0x…))'`, compose via ImageMagick). Avoid two `omarchy` font families — Qt can keep a stale `~/.local/share/fonts` copy even when `fc-match omarchy` is right. Refresh the font cache AND restart the shell (a `omarchy menu refresh` is not enough). Preview by swapping the packaged file in the VM or a fontconfig `<rejectfont>` rule; clean up temp fonts/rules afterwards. `[SRC:agents/skills/icon-font.md:L62-L75]`

## Command metadata hygiene

- Read `agents/skills/command-metadata.md` before touching `bin/`. `[SRC:agents/skills/command-metadata.md:L9-L10]`
- Keep metadata keys correct (`omarchy:group/name/summary/args/examples/alias/aliases/hidden/requires-sudo`) — the router reads the first 80 comment lines; explicit metadata matters for user-facing commands; routes must keep consistent with filenames. `[SRC:agents/skills/command-metadata.md:L9-L23]`
- `omarchy:examples` values stay meaningful and single-`|`-separated; only include it when args need explaining. `[SRC:agents/skills/command-metadata.md:L15-L23]`
- Migrations: author with `omarchy-dev-add-migration --no-edit`; idempotent, no shebang, never restart the shell. `[SRC:agents/skills/migrations.md:L107-L149]`