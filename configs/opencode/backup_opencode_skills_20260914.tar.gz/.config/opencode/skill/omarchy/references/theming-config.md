# Theming & Configuration Reference

> Quick tier (T1-low). Traced to `docs/theming.md`, `docs/file-layout.md`, `manual/06-themes.md`, `manual/39-backgrounds.md`, `manual/43-making-your-own-theme.md`.

## Contents

- [Theme layout](#theme-layout)
- [colors.toml tokens](#colorstoml-tokens)
- [Template placeholders](#template-placeholders)
- [shell.toml section keys](#shelltoml-section-keys)
- [Theme install hygiene](#theme-install-hygiene)
- [Custom .tpl templates](#custom-tpl-templates)
- [Light mode and extras](#light-mode-and-extras)

## Theme layout

- Themes live in `themes/<name>/`; system copies installed at `/usr/share/omarchy/themes/`, user themes at `~/.config/omarchy/themes/`. `[SRC:docs/theming.md:L3-L7]`
- `omarchy theme set <name>` stages the pending theme under `~/.local/state/omarchy/current/next-theme`. `[SRC:docs/theming.md:L20-L29]`
- Optional theme extras: `backgrounds/`, `preview.png`, `icons.theme`, `keyboard.rgb`, `light.mode`. `[SRC:docs/theming.md:L9-L15]`
- Making a theme *from* a cloned/installed source (git repo): the clone keeps colors, **drops** every `*.lua` (including `hyprland.lua`), terminal configs (`alacritty.toml`, `foot.ini`, `ghostty.conf`, `kitty.conf`), and `vscode.json`; **keeps** `btop.theme`, `chromium.theme`, `helix.toml`, `icons.theme`, `shell.toml`, backgrounds, previews; dropped files are regenerated from `colors.toml`. `[SRC:docs/theming.md:L52-L66]`
- A user theme (no inner git repo) will auto-appear in the theme menu. `[SRC:manual/43-making-your-own-theme.md:L3]`

## colors.toml tokens

- Core keys: `accent` (`#7aa2f7` default), `selection`, `muted`, `background`, `foreground`, plus the palette `red…blue`. `[SRC:docs/theming.md:L68-L127]`
- Every color key has `dark_` / `lighter_` / `bright_` variants; legacy aliases `bg`/`fg` map to `background`/`foreground`. `[SRC:docs/theming.md:L68-L127]`
- Light mode: `mode = "light"` at the top of `colors.toml`; legacy marker is an empty `light.mode` file at the theme root. `[SRC:manual/43-making-your-own-theme.md:L21]`

## Template placeholders

Available inside `{{ }}` templates that derive configs from the theme:

- `{{ accent }}` (literal hex `#7aa2f7`), `{{ accent_strip }}` (no `#`), `{{ accent_rgb }}` (decimal triple). `[SRC:docs/theming.md:L131-L176]`
- Mixing: `{{ mix <color> <color> <fraction> }}` and `{{ mix_rgb ... }}`. `[SRC:docs/theming.md:L131-L176]`
- Gradients: helpers `hypr_gradient`, `shell_gradient`, `gradient_start` (used by `hyprland.lua.tpl`). `[SRC:docs/theming.md:L354-L372]`

## shell.toml section keys

- Sections: `[bar] [controls] [popups] [tooltip] [notifications] [launcher] [menu] [polkit] [lock] [image-picker] [spacing] [font]`. `[SRC:docs/theming.md:L178-L192]`
- Override path: `shell.<section>.toml` in the theme, or replace the whole `shell.toml`. `[SRC:docs/theming.md:L178-L192]`
- The machine-level user file is `~/.config/omarchy/shell.toml`, watched live. `[SRC:docs/omarchy-shell.md:L171-L174]`
- Token singletons available to QML: `Color`, `Style`, `Border` (with `BorderSurface` helpers). `[SRC:docs/theming.md:L324-L350][SRC:docs/omarchy-shell.md:L192-L208]`
- `[controls]`: four states — `normal`, `hover-cursor`, `focus`, `selected`. `[SRC:docs/omarchy-shell.md:L223-L258]`
- `[spacing]`: a base `scale` plus tokens `controlPaddingX/Y`, `controlHeight`, `popupRowHeight`. `[SRC:docs/omarchy-shell.md:L260-L307]`
- `[font]`: base-size `rem` plus tokens from `caption` to `displayLarge`. `[SRC:docs/omarchy-shell.md:L311-L353]`
- `[bar]`: base sizes `size-horizontal`/`size-vertical` = 12px. `[SRC:docs/omarchy-shell.md:L357-L369]`

## Theme install hygiene

- Installing a third-party theme never runs code-bearing files (they are dropped — see above). `[SRC:docs/theming.md:L52-L66]`
- Theme names: must start with a letter/digit/underscore, remaining chars `letters/digits/._+-`; uppercase lowercased on install; spaces/quotes/non-English rejected. Distribution convention `omarchy-<name>-theme` (displayed as just `<name>`). `[SRC:manual/43-making-your-own-theme.md:L39-L43]`

## Custom .tpl templates

- Drop a `.tpl` in `~/.config/omarchy/themed/` named after the target config (e.g. `alacritty.toml.tpl`); it regenerates on every theme change; user templates override built-ins. `[SRC:manual/43-making-your-own-theme.md:L33-L35]`
- Built-in defaults live at `default/themed/*.tpl` in the source. `[SRC:AGENTS.md:L101-L103]`
- Placeholders usable in `.tpl`: `{{ background }}`, `{{ foreground }}`, `{{ accent }}`, `{{ red }}`, `{{ color0 }}`–`{{ color15 }}`; modifiers `_strip` (drop `#`) and `_rgb` (decimal triple). Sample: `alacritty.toml.tpl.sample`. `[SRC:manual/43-making-your-own-theme.md:L33-L35]`