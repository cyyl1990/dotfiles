# Updates, Migrations & Packages

> Quick tier (T1-low). Traced to `docs/update-process.md`, `docs/file-layout.md`, `agents/skills/migrations.md`, `agents/skills/install-scripts.md`, `manual/30-updates.md`, `manual/47-system-snapshots.md`, `manual/51-unattended-installs.md`.

## Contents

- [Update pipeline](#update-pipeline)
- [Channels](#channels)
- [Rollback](#rollback)
- [Migrations](#migrations)
- [Package/file layout](#packagefile-layout)
- [Provisioning layers](#provisioning-layers)
- [ISO/unattended installs](#isounattended-installs)

## Update pipeline

- The blessed path is `omarchy update`. Direct `pacman -Syu`/`yay -Syu` is blocked by `/usr/share/libalpm/hooks/00-omarchy-update-guard.hook`; deliberate bypass is `sudo env OMARCHY_ALLOW_DIRECT_PACMAN=1 pacman -Syu`. `[SRC:docs/update-process.md:L22-L99]`
- Guardrails: 10 GiB free-space check, snapper snapshot before changes, stay-awake during the run, full transcripts written to the log. `[SRC:docs/update-process.md:L109-L149]`
- State files: `update.lock` (serialize runs), `/tmp/omarchy-update.log`, `current/`, `migrations/`, `reboot-required`, `restart-*-required`. `[SRC:docs/update-process.md:L22-L99]`
- The login-only notifier is `omarchy-migrate-notify` (systemd service); the bar badge comes from `omarchy.system-update` → `omarchy-update-available`. `[SRC:docs/update-process.md:L151-L244]`
- Firmware: `_Update > Firmware` installs `fwupd` and flashes devices. `[SRC:manual/30-updates.md:L25]`

## Channels

- `stable` (default): releases, mirror ~1 month behind Arch. `edge`: dev builds + latest Arch. `rc`: pre-release validation. `dev`: git checkout of `~/omarchy` + edge (devs only). `[SRC:docs/update-process.md:L246-L258][SRC:manual/30-updates.md:L13-L19]`
- Switch via `_Update > Channel` or `omarchy channel set <name>`. `[SRC:manual/30-updates.md:L21]`

## Rollback

- A snapper snapshot is created each update; pick it in the Limine boot menu (snapshots restore the root fs only — never `/home`; `~/.config` is kept, fix old-format configs yourself). `[SRC:manual/30-updates.md:L33-L37][SRC:manual/47-system-snapshots.md:L3-L17]`
- `omarchy reinstall`/`omarchy reinstall configs` resets configs and downgrades packages; `omarchy-snapshot create`/`restore` are the programmatic controls. `[SRC:manual/47-system-snapshots.md:L3-L11]`

## Migrations

- One-time repair scripts live in `migrations/*.sh`; they run per-user through `omarchy-migrate` (during `omarchy update` and at login via the notifier). Per-user markers at `~/.local/state/omarchy/migrations/<filename>`; scripts must be idempotent. `[SRC:agents/skills/migrations.md:L5-L32]`
- Inspect pending: `omarchy-migrate --pending`. `[SRC:agents/skills/migrations.md:L88-L105]`
- Authoring (`omarchy-dev-add-migration --no-edit`): file name `<unix timestamp>.sh`, octal 0644, **no shebang**, first line an `echo` of the description, use helper commands, never restart the shell, strictly ordered and synchronous. `[SRC:agents/skills/migrations.md:L107-L149]`
- The Omarchy 4.0 upgrade itself goes through `bin/omarchy-upgrade-to-quattro`, not the migration runner. `[SRC:agents/skills/migrations.md:L151-L172]`

## Package/file layout

- Two packages: `omarchy` and `omarchy-settings`. `[SRC:docs/file-layout.md:L7-L31]`
- Build map: `bin/**` → `/usr/bin/` + symlinks; `config/**` → `/etc/skel/.config/**`; `etc/**` → `/etc/**`; `etc-overrides/**` overwrite via `cp -f` on upgrade (`.bashrc`, `nsswitch.conf`, …); `default/**` → catch-all. `[SRC:docs/file-layout.md:L64-L140]`
- Env bootstrap: `default/bash/env-bootstrap` sources `/etc/omarchy.conf`, else forces `OMARCHY_PATH=/usr/share/omarchy`. `[SRC:docs/file-layout.md:L165-L203]`
- Setup scripts: `omarchy-apply-system` (root, ISO finalization; sources `install/{config,hardware,login,post-install}/all.sh`), `omarchy-apply-hardware` (idempotent), `omarchy-finalize-user` (per-user + `install/user/all.sh`), `omarchy-reinstall-configs` (destructive resync). `[SRC:agents/skills/install-scripts.md:L8-L15]`
- `install/` leaf scripts are sourced via `run_logged $OMARCHY_INSTALL/path` (no shebangs); avoid `exit` unless aborting; use `$OMARCHY_INSTALL`/`$OMARCHY_PATH`, never hardcoded paths. `[SRC:agents/skills/install-scripts.md:L11-L13]`
- Cluster: the user skill/capture/etc. preferences sync between home-package layers. `[SRC:docs/file-layout.md:L33-L49]`

## Provisioning layers

- Three `$HOME` layers: **Seed** (`/etc/skel` from omarchy-settings), **Finalize** (`omarchy-provision-user` — skill symlinks into `~/.agents/skills`, `~/.claude/skills`, `~/.codex/skills`, `~/.pi/agent/skills`, `~/.gemini/config/skills`, `~/.hermes/skills`, plus xdg-user-dirs, XKB layout, chromium/HEY desktop files), **Resync** (`omarchy-reinstall-configs`). `[SRC:docs/file-layout.md:L33-L49,L205-L231]`
- Deferred provisioning: `omarchy-apply-system --defer-provisioning`; first-run user setup via `omarchy-provision-first-run`. `[SRC:docs/file-layout.md:L49,L267-L305]`
- Completion markers use `omarchy-done`. `[SRC:docs/file-layout.md:L205-L231]`

## ISO/unattended installs

- The OS installs only through the ISO; interactive types are full-disk (default, LUKS, wipes) or free-space/dual-boot. `[SRC:manual/02-getting-started.md:L3-L7][SRC:manual/50-dual-boot-install.md:L5-L31]`
- Auto-install: a second drive labeled `cidata` (cloud-init NoCloud) triggers unattended setup. Config files inside it live in `/root`: `user_configuration.json` (required), `user_credentials.json` (required unless `defer-provisioning` present — that delays personal setup for imaging rigs), `user_full_name.txt`, `user_email_address.txt`, `user_encrypt_installation.txt`, `authorized_keys`, `tailscale_authkey`. `[SRC:manual/51-unattended-installs.md:L3-L23]`
- Password hashes: `openssl passwd -6 "<pass>"`; SSH from `authorized_keys` enables `sshd` + firewall; Tailscale with a reusable pre-authorized key joins the tailnet on first boot. `[SRC:manual/51-unattended-installs.md:L21-L29]`
- Build the cidata ISO: `mkdir cidata && cp … cidata/ && genisoimage -output cidata.iso -volid cidata -joliet -rock cidata/`; enable both ISOs as cdroms and boot the OS disk first. `[SRC:manual/51-unattended-installs.md:L36-L57]`