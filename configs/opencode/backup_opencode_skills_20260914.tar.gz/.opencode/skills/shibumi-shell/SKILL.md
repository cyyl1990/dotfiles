---
name: shibumi-shell
description: "Use when diagnosing and repairing Shibumi Shell (native Omarchy Quattro plugin suite running in Quickshell): crash-loops, IPC failures, health errors, transactional install/update/repair/rollback, plugin activation, and host-contract gaps."
triggers:
  - shibumi bar not working
  - shibumi plugin not showing
  - shibumi health error
  - shibumi crash-loop quickshell
  - shibumi IPC function not found
  - shibumi-suite status repair activate
  - hancore.shibumi
  - omarchy quattro shibumi
---

# Shibumi Shell — Diagnostics & Repair

Shibumi is a native Omarchy Quattro plugin suite (24 plugins) running inside the
single production Quickshell process. This skill covers diagnosis and repair
procedures. Every instruction traces to `docs/` in the Shibumi-Shell repository.

## Quick Start

```bash
# Check install/activation state
./scripts/shibumi-suite status
omarchy plugin list

# Activate the suite (restores Shibumi + managed layout)
./scripts/shibumi-suite activate --dry-run
./scripts/shibumi-suite activate

# Transactional repair of missing/modified/ownership-mismatched payloads
./scripts/shibumi-suite repair --dry-run
./scripts/shibumi-suite repair
```

Read-only diagnostics: `./scripts/shibumi-suite status`, `omarchy plugin list`,
`pgrep -af quickshell`, `hyprctl monitors -j`, `qs log`.
[SRC:docs/development/troubleshooting.md:L10]

## Key API Summary

The suite is controlled through `./scripts/shibumi-suite` subcommands (not
`omarchy plugin add` on the repo root — it is a 24-plugin suite, not one root
plugin). [SRC:docs/development/troubleshooting.md:L21]

| Command | Purpose | Source |
|---------|---------|--------|
| `shibumi-suite status` | Check install/activation state | [SRC:docs/development/troubleshooting.md:L10] |
| `shibumi-suite activate [--dry-run]` | Activate suite, restore managed layout | [SRC:docs/development/troubleshooting.md:L17] |
| `shibumi-suite repair [--dry-run]` | Transactional repair of payloads/plugins | [SRC:docs/development/troubleshooting.md:L31] |
| `shibumi-suite update [--dry-run]` | Update (refuses drifted/foreign/symlinked) | [SRC:docs/development/troubleshooting.md:L65] |
| `shibumi-suite migrate [--dry-run]` | Migrate then `omarchy update` | [SRC:docs/install.md:L113] |
| `shibumi-suite deactivate [--keep-layout]` | Select Omarchy while retaining Shibumi | [SRC:docs/configuration.md:L135] |
| `shibumi-suite uninstall [--keep-settings]` | Remove suite | [SRC:docs/install.md:L273] |
| `omarchy plugin list` | List Omarchy plugins | [SRC:docs/development/troubleshooting.md:L11] |
| `qs ipc -p /usr/share/omarchy/shell call shibumi-suite <method>` | Appearance IPC | [SRC:docs/configuration.md:L41] |

## Diagnostics & Repair

### Shibumi does not appear

```bash
./scripts/shibumi-suite status
omarchy plugin list
```
If installed but inactive:
```bash
./scripts/shibumi-suite activate --dry-run
./scripts/shibumi-suite activate
```
Do not use `omarchy plugin add` on the repository root.
[SRC:docs/development/troubleshooting.md:L5]

### A plugin was removed or disabled individually

The generic Omarchy plugin menu manages one plugin root at a time and does not
know Shibumi's suite dependencies. Restore the complete suite:
```bash
./scripts/shibumi-suite status
./scripts/shibumi-suite repair --dry-run
./scripts/shibumi-suite repair
```
Repair is transactional and refuses foreign replacement targets. Do not recreate
missing suite directories by hand.
[SRC:docs/development/troubleshooting.md:L24]

### An update is refused

`shibumi-suite update` refuses: inactive or configuration-drifted installations;
unmanaged or foreign plugin directories; symlinked payloads and special files;
unsafe manifest entry points; invalid or inconsistent install state. Run `status`
and resolve the reported drift. Use `activate` before `update` when the suite is
intentionally installed but inactive. Use `repair` when payloads are missing,
modified, ownership-mismatched, or were disabled individually.
[SRC:docs/development/troubleshooting.md:L63]

### An operation was interrupted

Keep the state directory intact and rerun the intended suite command. Mutating
commands recover unfinished transactions before starting new work. Do not delete
transaction directories or ownership markers manually.
[SRC:docs/development/troubleshooting.md:L77]

### Health checks (read-only)

Opening Health refreshes a missing or older-than-five-minutes result once; no
background timer polls. **Run checks** is the explicit refresh action. Check
status is `ok` / `warning` / `error` / `info`; report state is `healthy` /
`warning` / `error`. [SRC:docs/health-diagnostics.md:L24]

Ownership attribution: every check carries an `owner` of `shibumi`, `omarchy`,
`third-party`, or `unknown`. `/usr/share/omarchy/**` findings are Omarchy-owned;
installed `hancore.shibumi.*` roots are Shibumi-owned; unverified explicit plugin
fields remain `unknown`. Ownership must not be assigned by guesswork.
[SRC:docs/health-diagnostics.md:L57]

### Install

From AUR:
```bash
omarchy pkg aur add shibumi-shell && shibumi-shell install --yes
```
[SRC:docs/install.md:L28]

From source checkout:
```bash
git clone https://github.com/HANCORE-linux/Shibumi-Shell.git
./scripts/shibumi-suite install --dry-run
./scripts/shibumi-suite install
```
[SRC:docs/install.md:L49,L63]

Options: `./scripts/shibumi-suite install --no-activate --keep-layout --yes`
[SRC:docs/install.md:L97]

### Update flow

```bash
git pull --ff-only
./scripts/shibumi-suite update --dry-run
./scripts/shibumi-suite update
```
[SRC:docs/install.md:L139]

Rollback a package:
```bash
sudo pacman -U /var/cache/pacman/pkg/shibumi-shell-<older-version>-any.pkg.tar.zst
```
[SRC:docs/install.md:L178]

### Check for updates (read-only)

A checkout uses `git fetch` for its configured upstream and never pulls,
checks out, merges, installs, or changes the working tree. A package install
queries the official AUR RPC for the published `shibumi-shell` version and never
treats `/usr/share/shibumi-shell` as Git. [SRC:docs/health-diagnostics.md:L89]

## Gotchas

- **Never `omarchy plugin add` on the repo root** — Shibumi is a 24-plugin
  suite, not one root plugin. Use `shibumi-suite activate`/`repair`.
  [SRC:docs/development/troubleshooting.md:L21]
- **Don't delete transaction dirs manually** — mutating commands recover
  unfinished transactions; manual deletion breaks recovery.
  [SRC:docs/development/troubleshooting.md:L81]
- **`omarchy bar defaults` is destructive** — it replaces the complete `bar`
  object; Shibumi cannot reconstruct personal `bar.shibumi` settings the
  defaults command deleted. Prefer `omarchy bar reset`.
  [SRC:docs/configuration.md:L137]
- **Health is read-only** — no background polling; "Run checks" is explicit.
  [SRC:docs/health-diagnostics.md:L24]

<!-- [MANUAL:additional-notes] -->
<!-- Append operator notes here; preserved across updates. -->
<!-- [/MANUAL:additional-notes] -->
