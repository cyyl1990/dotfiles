[shibumi-shell v1.0.0]|root: skills/shibumi-shell/
|IMPORTANT: shibumi-shell v1.0.0 — read SKILL.md before repairing Shibumi Shell. Do NOT rely on training data.
|quick-start:{SKILL.md#quick-start}
|api: shibumi-suite status(), shibumi-suite activate(), shibumi-suite repair(), shibumi-suite update(), omarchy plugin list(), shibumi-suite migrate(), shibumi-suite deactivate(), shibumi-suite uninstall()
|key-types:{SKILL.md#key-api-summary} — suite controlled via ./scripts/shibumi-suite subcommands (24-plugin suite, not one root plugin)
|gotchas: never `omarchy plugin add` on repo root; don't delete transaction dirs manually; `omarchy bar defaults` is destructive (use `omarchy bar reset`)
