# Shibumi Shell — Full Procedure Reference

All procedures trace to `docs/` in the Shibumi-Shell repository (commit `0c8f13e`).

## Lifecycle & Diagnostics

### shibumi-suite status
Check install/activation state of the 24-plugin suite.
[SRC:docs/development/troubleshooting.md:L10]

### shibumi-suite activate [--dry-run]
Activate the suite (restores Shibumi + managed layout). Use before `update`
when installed-but-inactive. [SRC:docs/development/troubleshooting.md:L17]

### shibumi-suite repair [--dry-run]
Transactional repair of missing/modified/ownership-mismatched payloads or
individually-disabled plugins. Refuses foreign replacement targets.
[SRC:docs/development/troubleshooting.md:L31]

### shibumi-suite update [--dry-run]
Refuses inactive/drifted, unmanaged/foreign, symlinked payloads, unsafe
manifests, invalid install state. [SRC:docs/development/troubleshooting.md:L65]

### shibumi-suite migrate [--dry-run]
Migrate suite, then `omarchy update`. [SRC:docs/install.md:L113]

### shibumi-suite deactivate [--keep-layout]
Select Omarchy while retaining Shibumi. [SRC:docs/configuration.md:L135]

### shibumi-suite uninstall [--dry-run] [--yes] [--keep-settings]
Remove suite. `omarchy pkg drop shibumi-shell` drops the AUR package.
[SRC:docs/install.md:L259,L273]

### omarchy plugin list
List Omarchy plugins (verify Shibumi presence). [SRC:docs/development/troubleshooting.md:L11]

### qs ipc -p /usr/share/omarchy/shell call shibumi-suite <method>
Appearance IPC — call suite methods (e.g. appearance changes) via Quickshell.
[SRC:docs/configuration.md:L41]

## Install

### From AUR
`omarchy pkg aur add shibumi-shell && shibumi-shell install --yes`
[SRC:docs/install.md:L28]

### From source checkout
```bash
git clone https://github.com/HANCORE-linux/Shibumi-Shell.git
./scripts/shibumi-suite install --dry-run
./scripts/shibumi-suite install
```
[SRC:docs/install.md:L49,L63]

### Install options
`--no-activate --keep-layout --yes` [SRC:docs/install.md:L97]

## Update & Rollback

### Update flow
```bash
git pull --ff-only
./scripts/shibumi-suite update --dry-run
./scripts/shibumi-suite update
```
[SRC:docs/install.md:L139]

### Rollback package
`sudo pacman -U /var/cache/pacman/pkg/shibumi-shell-<older>-any.pkg.tar.zst`
[SRC:docs/install.md:L178]

### Check for updates (read-only)
Checkout: `git fetch` upstream, never pulls/merges/installs. Package: AUR RPC
query for `shibumi-shell`, never treats `/usr/share/shibumi-shell` as Git.
[SRC:docs/health-diagnostics.md:L89]

## Repair Scenarios

### Plugin removed/disabled individually
```bash
./scripts/shibumi-suite status
./scripts/shibumi-suite repair --dry-run
./scripts/shibumi-suite repair
```
[SRC:docs/development/troubleshooting.md:L24]

### Interrupted operation
Keep state dir intact; rerun intended suite command. Mutating commands recover
unfinished transactions. Never delete transaction dirs/ownership markers.
[SRC:docs/development/troubleshooting.md:L77]

### Bar reset vs defaults
`omarchy bar reset` selects stock host without full defaults reset.
`omarchy bar defaults` replaces complete `bar` object (Shibumi cannot
reconstruct deleted personal `bar.shibumi` settings). [SRC:docs/configuration.md:L137]

## Health Diagnostics

### Read-only checks
Opening Health refreshes missing/older-than-5-min result once; "Run checks" is
explicit refresh. No background polling. [SRC:docs/health-diagnostics.md:L24]

### Ownership attribution
Every check carries owner: `shibumi` / `omarchy` / `third-party` / `unknown`.
`/usr/share/omarchy/**` = Omarchy; `hancore.shibumi.*` = Shibumi; unverified =
unknown. Never guess. [SRC:docs/health-diagnostics.md:L57]

### Collect diagnostics (read-only)
`./scripts/shibumi-suite status`, `omarchy plugin list`, `pgrep -af quickshell`,
`hyprctl monitors -j`, `qs log`. [SRC:docs/development/troubleshooting.md:L97]
